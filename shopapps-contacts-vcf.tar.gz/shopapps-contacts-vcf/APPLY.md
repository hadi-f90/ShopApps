# Contacts VCF + P0 hygiene pack

## 1. VCF (Contacts MVS)

| Pack | → Project |
|------|-----------|
| `src/apps/contacts/vcf.py` | **new** |
| `src/core/services/contact_service.py` | **replace** |
| `src/apps/contacts/main.py` | **replace** |
| `src/apps/contacts/forms.py` | **replace** (message_fa) |
| `tests/unit/test_vcf.py` | **new** |
| `.ai_files/specs/contacts-mvs-spec.md` | **replace** |

## 2. Hygiene

Follow `HYGIENE.md` — remove snippet files from `src/`.

## 3. README

Replace root `README.md` with pack `README.md`.

## 4. Social → Phase 2

Apply `ROADMAP_SOCIAL_NOTE.md` to `.ai_files/roadmap.md`.
Optional: change social placeholder text to «فاز ۲ — به تعویق افتاد».

## Verify

```bash
pytest tests/unit/test_vcf.py tests/unit/test_contact_service.py -q
# Manual: Contacts → ورود VCF / خروجی VCF
```

## Suggested commits

1. `feat(contacts): VCF import/export via ContactService`
2. `test(contacts): pure VCF parse/serialize unit tests`
3. `docs: honest README; Social deferred to Phase 2; contacts spec AC`
4. `chore: remove apply-pack snippet files from src/`
