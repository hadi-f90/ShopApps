# Roadmap edit (apply to .ai_files/roadmap.md)

## Under Phase 1 §5 Social/Messaging — replace with:

### 5. Social/Messaging
- **Deferred to Phase 2.** Not required for the MVS success criterion
  (contact → sale → receipt → stock). Sidebar entry remains a labeled
  placeholder only.

## Under Phase 2 — ensure present:

- Social: Message template CRUD + shop signature; manual send simulation;
  later real SMS/IM integration.
