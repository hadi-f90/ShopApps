# Delete leftover snippet files from the repo

```bash
git rm -f src/core/services/contact_service_phone_snippet.py \
          src/apps/contacts/REFRESH_SNIPPET.txt 2>/dev/null || true
rm -f src/core/services/contact_service_phone_snippet.py \
      src/apps/contacts/REFRESH_SNIPPET.txt
```

These were apply-pack leftovers and must not ship under `src/`.
